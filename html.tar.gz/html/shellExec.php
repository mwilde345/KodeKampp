<?php
	$freq = $_POST['frequency'];
	$packetNum = $_POST['packets'];
	$count = 1;
	$batches = $_POST['batches'];
	$button = $_POST['button'];
	while($button == 'startSniff'){
		if($count > $batches) break;
		$executeString = '/sharkSwim.sh '.$packetNum.' output'.$count.'.txt';
		$result = exec($executeString);	
		$print = 'Finished Sniff Batch';
		$count ++;
		sleep($freq);
	}elseif($button == 'stopSniff'){
		$result = exec('killall -9 tshark');
		$result = exec('/stopSwim.sh');
		$print = 'Stopped Sniff';
	}elseif($button == 'deleteFile') {
		$result = exec('/ftpDelete.sh');
		$print = 'Deleted "output.txt files"';
	}else{
		echo $print;
	}
?>
