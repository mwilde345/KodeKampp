<?php
	
?>

<html>
<head>
<meta content="text/html; charset=UTF-8"></meta>
<title>Packet Sniffing Start Page</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script src="/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="/css/bootstrap.css"/>
<link rel="stylesheet" type="text/css" href="/css/custom.css"/>
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300' rel='stylesheet' type='text/css'>
<script type="text/javascript">
	$(document).ready(function(){
		$("button").click(function(e){
			e.preventDefault();
			$.ajax({
				type: "POST",
				url: "shellExec.php",
				data: {packets:$("#packetLength").val(),
					frequency:$("#frequency").val(),
					batches:$("#batches").val(),
					button:this.name}
			}).done(function(result,status){
				
				$("#resultOut").val(result);
			});	
		});
	});
</script>
</head>
<body>
<video playsinline autoplay muted loop>
<source src="/packets.mp4" type="video/mp4">Not Supported</source>
<source src="/packets.webm" type="video/webm">Not Supported</source>
</video>
<div class="row" style="padding:50px 50px;">
<div class="col-lg-6 col-md-offset-3">
<div class="panel panel-info">
<h1 class="panel-title panel-heading" style="text-align: center">Begin Packet Filtering Using the Form Below</h1>
	<div class="panel-body">
	<div class="form-style-8">
	<label for="packetLength">Enter Number of Packets per Batch</label></br>
	<input type="number" id="packetLength" placeholder="Enter Number of Packets" name="packetLength"/></br>
	<label for="frequency">Enter Frequency of Packet Fetching</label></br>
	<input type="number" id="frequency" placeholder="How often to fetch" name="frequency"/></br>
	<label for="batches">How Many Batches Would You Like?</label></br>
	<input type="number" id="batches" placeholder="How many batches?" name="batches"/></br>
	<button name="startSniff">Begin Sniff</button>
	<button name="stopSniff">Stop Sniff</button>
	<button name="deleteFile">Delete Log File</button></br></br>
	<textarea id="resultOut" placeholder="Ajax Result Here"></textarea>
	</div>
</div>
</div>
</div>
</div>

</body>
</html>
